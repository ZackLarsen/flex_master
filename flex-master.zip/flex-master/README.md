# flex
Using Flex Dashboards to create presentations in R

Interactive HTML page available at:
https://ghe.fyiblue.com/pages/U383387/flex/Divvy_dashboard.html

![Ward_density](Ward_density.png)

![Chord_neighborhoods](neighborhood_chord.PNG)

![Chord_diagram](Chord_diagram.png)
